// Edit your details here — they're used across the whole site.
export const SITE = {
  name: 'Blake Wood',
  title: 'Blake Wood Ink',
  tagline: 'Custom tattoos by appointment in Toronto.',
  city: 'Toronto',
  instagram: 'blakewoodink',
  email: 'hello@blakewoodink.com', // replace with your booking email
  rate: '$200 / hour',
};
