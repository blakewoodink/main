// Collects every Markdown post in src/pages/blog, newest first.
// Posts with `draft: true` in their frontmatter are left out.
export function getPosts() {
  const modules = import.meta.glob('./pages/blog/*.md', { eager: true });
  return Object.values(modules)
    .filter((p) => !p.frontmatter.draft)
    .sort((a, b) => new Date(b.frontmatter.date) - new Date(a.frontmatter.date));
}
