---
layout: ../../layouts/Post.astro
title: Aftercare, kept simple
description: The short version of how to look after a new tattoo.
date: 2026-09-20
---

A new tattoo is an open wound for the first while, and the way you treat it in the first two weeks shows up for years. The basics:

- Leave the wrap on for as long as I tell you on the day.
- Wash gently with clean hands, unscented soap and lukewarm water.
- Pat dry with a clean paper towel, then let it air out.
- Use a thin layer of unscented moisturiser. Thin is the key word.
- Don't pick or scratch the flakes. Let them go on their own.
- Keep it out of pools, baths, the lake and direct sun until it's healed.

If something looks or feels wrong, like heat, spreading redness or swelling that gets worse instead of better, see a doctor and then let me know.
