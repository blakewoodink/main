---
layout: ../../layouts/Post.astro
title: How booking works
description: What to send me, what happens next, and how the drawing comes together.
date: 2026-09-24
---

Every tattoo I do is drawn for the person wearing it, so booking takes a little more back and forth than walking in off the street. Here's how it goes.

## Send the idea

Email me with the idea in a few sentences, where it's going, and roughly how big. Reference images help, but you don't need a finished design. That's my job.

## Pick a date

Once we've talked it through, I'll offer a few dates. A deposit holds yours and comes off the final price.

## See the drawing

I send the drawing ahead of time so we can adjust it together. On the day, we place the stencil, check it in the mirror, and start.

> Bring questions. There's no such thing as asking too many before something permanent.

[Request a booking](/booking)
